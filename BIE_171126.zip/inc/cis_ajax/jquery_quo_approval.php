<?php
ob_start();

session_start();

require_once("../common/dbconnect.php");
require_once("../common/functions.php");
require_once("../common/dbhandler.php");
require_once("../common/csrf.php");
require_once("../common/access.php");

$conn = new dbconnect();
$dbconn= new dbhandler();

// 2026-10-13 login + csrf + approver check - same rule as the approve button (admin or the quotation's branch)
// 2026-10-13 approver from Task Settings (QUOTATION A, per branch)
// 2026-10-13 only a quotation sent for approval and not yet decided

// ini_set('display_errors', '1');
// ini_set('display_startup_errors', '1');
// error_reporting(E_ALL);

fnAjaxGuard();
$quo_branch = $dbconn->GetSingleReconrd("tbl_quotation", "bie_branch_id", "quo_id", (int)$_POST["id"]);
if (!fnTaskCan('QUOTATION', 'A', $quo_branch)) {
	fnAccessDenied(true);
}


	$update_id = $_POST["id"];
	$task = $_POST["task"];
	$remarks = $_POST["remarks"];
	
		
	$stmt = null;
	$stmt = $conn->prepare("UPDATE tbl_quotation set  quo_approve_status = :quo_approve_status, quo_approve_id = :quo_approve_id, quo_approve_date_time= :quo_approve_date_time,
		quo_approve_remarks= :quo_approve_remarks WHERE quo_id = :quo_id AND quo_verify_status = 1 AND quo_approve_status = 0");

	if ($task == 'QUO_APP') 
	{
		$data = array(
			':quo_approve_status' =>  "1",
			':quo_approve_id' =>$_SESSION['_user_id'],
			':quo_approve_date_time' =>date('Y-m-d H:i:s'),
			':quo_approve_remarks' =>$remarks,
			':quo_id' => $update_id			
		);
		
		$stmt->execute($data);
		$_SESSION['_msg'] = "Quotation Approved..!";
	}

	if ($task == 'QUO_REJ') {		
		$data = array(
			':quo_approve_status' =>  "2",
			':quo_approve_id' =>$_SESSION['_user_id'],
			':quo_approve_date_time' =>date('Y-m-d H:i:s'),
			':quo_approve_remarks' =>$remarks,
			':quo_id' => $update_id			
		);
		$stmt->execute($data);

		$_SESSION['_msg'] = "Quotation Rejected..!";
	}
	
// nothing changed: the document was already approved / rejected or is not waiting for this step
if (isset($stmt) && $stmt instanceof PDOStatement && $stmt->rowCount() == 0) {
	$_SESSION['_msg'] = '';
	$_SESSION['_msg_err'] = "Not waiting for approval - it may already be approved or rejected..!";
	http_response_code(409);
}

?>
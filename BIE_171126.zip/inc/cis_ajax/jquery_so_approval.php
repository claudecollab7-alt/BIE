<?php
ob_start();

session_start();

require_once("../common/dbconnect.php");
require_once("../common/functions.php");
require_once("../common/dbhandler.php");
require_once("../common/csrf.php");
require_once("../common/access.php");

$conn = new dbconnect();
$dbconn = new dbhandler();

// 2026-10-13 login + csrf + approver check (same rule as the approve button)
// 2026-10-13 approver from Task Settings (SALES_ORDER A)
// 2026-10-13 only a verified sales order still waiting (as the buttons)

// ini_set('display_errors', '1');
// ini_set('display_startup_errors', '1');
// error_reporting(E_ALL);

fnAjaxGuard();
$so_branch = $dbconn->GetSingleReconrd("tbl_sales_order", "bie_branch_id", "so_id", (int)$_POST["so_id"]);
if (!fnTaskCan('SALES_ORDER', 'A', $so_branch)) {
	fnAccessDenied(true);
}


$update_id = $_POST["so_id"];
$task = $_POST["task"];
$remarks = $_POST["remarks"];


$stmt = null;
$stmt = $conn->prepare("UPDATE tbl_sales_order set  so_approve_status = :so_approve_status, so_approve_by = :so_approve_by, so_approve_date_time = :so_approve_date_time,
	so_remarks = :so_remarks, so_status = :so_status WHERE so_id = :so_id AND so_verify_status = 1 AND so_status = 1");



if ($task == 'SO_APP') {
	$_REQUEST['created_dtm'] = date('Y-m-d H:i:s');

	$data = array(
		':so_approve_status' =>  "1",
		':so_approve_by' => $_SESSION['_user_id'],
		':so_approve_date_time' => $_REQUEST['created_dtm'],
		':so_remarks' => $remarks,
		':so_status' => "5",
		':so_id' => $update_id
	);

	$stmt->execute($data);

	$_SESSION['_msg'] = "Sales Approved..!";
}

if ($task == 'SO_REJ') {
	$data = array(
		':so_approve_status' =>  "2",
		':so_approve_by' => $_SESSION['_user_id'],
		':so_approve_date_time' => $_REQUEST['created_dtm'],
		':so_remarks' => $remarks,
		':so_status' => "4",
		':so_id' => $update_id
	);
	$stmt->execute($data);


	$_SESSION['_msg'] = "Sales Rejected..!";
}// nothing changed: the document was already approved / rejected or is not waiting for this step
if (isset($stmt) && $stmt instanceof PDOStatement && $stmt->rowCount() == 0) {
	$_SESSION['_msg'] = '';
	$_SESSION['_msg_err'] = "Not waiting for approval - it may already be approved or rejected..!";
	http_response_code(409);
}



<?PHP

ob_start();
// own session when the form posts here directly - included in a page it is already running
if (session_status() === PHP_SESSION_NONE) {
	session_start();
}

require_once("inc/common/dbconnect.php");
require_once("inc/common/functions.php");
require_once("inc/common/dbhandler.php");
require_once("inc/common/csrf.php");
require_once("inc/common/access.php");
require_once("inc/common/db_txn.php");

$conn = new dbconnect();
$dbconn= new dbhandler();

// 2026-10-01 csrf + form token guard, transaction rollback, errors logged
// 2026-10-06 loads its own csrf and txn helpers - opened on its own it died on csrf_fields()
// 2026-10-13 session started when posted directly - every confirm failed the csrf check since 2026-10-01
// 2026-10-13 cancel allowed only for the user who sees the cancel link (admin); cancelled-by is the user, was always 1
// 2026-10-13 cancel for Sales Order Cancel in Task Settings (SO_CANCEL A) - approving and cancelling are different people

ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

if (isset($_POST['CONFIRM']))
{
	if (!csrf_check('modal_so_reject_dets')) {
		csrf_fail('lst_so_approval.php');
	}
	if (!fnTaskCan('SO_CANCEL', 'A', $dbconn->GetSingleReconrd("tbl_sales_order", "bie_branch_id", "so_id", (int)$_REQUEST['so_id']))) {
		fnAccessDenied(false, 'lst_sales_order.php');
	}

	try {
		db_begin($conn);
		$so_date = $dbconn->GetSingleReconrd("tbl_sales_order","so_date","so_id",$_REQUEST['so_id']);
		// $_REQUEST['so_credit_due_date'] = date('Y-m-d', strtotime($so_date. ' + '.$_REQUEST['so_credit_days'].' days')); 
		$stmt = null;				
		$stmt = $conn->prepare("UPDATE tbl_sales_order SET so_cancel_by = :so_cancel_by, so_cancel_date_time = :so_cancel_date_time, so_cancel_reason = :so_cancel_reason, so_status = :so_status, 
		so_approve_status = :so_approve_status, so_cancel_status = :so_cancel_status, so_credit_days = :so_credit_days, accounts_status = :accounts_status, pay_status = :pay_status WHERE so_id = :so_id");
		$data = array(
			'so_id'=>$_REQUEST['so_id'],
			':so_cancel_by' => $_SESSION['_user_id'],
			':so_cancel_date_time' => date('Y-m-d H:i:s'),
			':so_cancel_reason' => $_REQUEST['so_cancel_reason'],
			':so_status' => '6',
			':so_approve_status' => '0',
			':so_cancel_status' => '1', 
			':so_credit_days' => '0', 
			':accounts_status' => '0', 
			':pay_status' => '0' 
		
		);
   
		$stmt->execute($data);
	    // .

	// print_r($data);die();
		db_commit($conn);
		header("location:lst_sales_order.php");	
		die();
	
	} catch (Exception $e) {
		fnLogError($e);
		db_rollback($conn);
		$_SESSION['_msg_err'] = filter_var($e->getMessage(), FILTER_SANITIZE_STRING);
	}
	header("location:lst_so_approval.php");
	die();
}
?>
<!-- Basic modal -->

<!-- Basic modal -->
<div id="modalRejectDets" class="modal fade" tabindex="-1" data-backdrop="false">
		<div class="modal-dialog   modal-dialog-scrollable">
			<div class="modal-content">
				<div class="modal-header pb-2 pt-2 bg-modal">
					<h6 class="modal-title" style="width: 800px;">
	                <span id="m_sales_rej_rec" class="font-weight-bold"></span></h6>
					<!-- <h6 class="modal-title font-weight-bold"><span id="m_sales_rec"></span> - <span id="inv_netamt" class="font-weight-bold"></span></h6> -->
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
            <form action="modal_so_reject_dets.php" method="POST">
            	<?php csrf_fields('modal_so_reject_dets'); ?>
                <div class="modal-body py-0" id="m_sales_rej_code">				
                    <div class="col-md-6 pt-5 pb-5 text-center">
                        <span id="spinner-light" class="text-loading">
                            <i class="icon-spinner spinner mr-2 "></i>
                                Loading ...
                        </span>
                    </div>
                </div>
                <div class="container">
					<div style="text-align: center"><hr>
	
						<INPUT class="btn btn-danger" type="submit" name="CONFIRM" value="Cancelled">
						<INPUT class="btn btn-light mr-2" type="button" name="cancel" value="Close" onClick="javascript:window.location.href='lst_sales_order.php'">
					
					</div>
				</div><br>
			</form>
			
			<div class="modal-footer pt-0 pb-2 bg-modal">				
				<!--button type="button" class="btn btn-light" data-dismiss="modal">Close</button-->				
			</div>
		</div>
	</div>
		</div>			
<!-- /basic modal -->
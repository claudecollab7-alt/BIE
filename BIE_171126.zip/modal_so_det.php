<?PHP

ob_start();
// own session when the form posts here directly - included in a page it is already running
if (session_status() === PHP_SESSION_NONE) {
	session_start();
}

require_once("inc/common/dbconnect.php");
require_once("inc/common/functions.php");
require_once("inc/common/dbhandler.php");
require_once("inc/common/csrf.php");
require_once("inc/common/access.php");
require_once("inc/common/db_txn.php");

$conn = new dbconnect();
$dbconn= new dbhandler();

// 2026-10-01 csrf + form token guard, transaction rollback, errors logged
// 2026-10-06 loads its own csrf and txn helpers - opened on its own it died on csrf_fields()
// 2026-10-13 session started when posted directly - every confirm failed the csrf check since 2026-10-01
// 2026-10-13 credit approval allowed only for the users on the credit-approval dashboard tile; approver saved as the user
// 2026-10-13 credit approval for approvers in Task Settings (CREDIT_SALES A)
// 2026-10-13 only a sales order waiting for credit approval (pay_status 3)

// ini_set('display_errors', '1');
// ini_set('display_startup_errors', '1');
// error_reporting(E_ALL);

if (isset($_POST['CONFIRM']))
{
	if (!csrf_check('modal_so_det')) {
		csrf_fail('lst_sales_receipt.php');
	}
	if (!fnTaskCan('CREDIT_SALES', 'A', $dbconn->GetSingleReconrd("tbl_sales_order", "bie_branch_id", "so_id", (int)$_REQUEST['so_id']))) {
		fnAccessDenied(false, 'lst_so_approval.php');
	}

	try {
		db_begin($conn);
		$so_date = $dbconn->GetSingleReconrd("tbl_sales_order","so_date","so_id",$_REQUEST['so_id']);
		$_REQUEST['so_credit_due_date'] = date('Y-m-d', strtotime($so_date. ' + '.$_REQUEST['so_credit_days'].' days')); 
		$stmt = null;				
		$stmt = $conn->prepare("UPDATE tbl_sales_order SET so_credit_approval_remarks = :so_credit_approval_remarks, so_credit_days = :so_credit_days, so_credit_due_date = :so_credit_due_date, so_approve_status = :so_approve_status, so_approve_by = :so_approve_by, pay_status = :pay_status ,so_approve_date_time = :so_approve_date_time WHERE so_id = :so_id AND pay_status = 3");
		$data = array(
			'so_id'=>$_REQUEST['so_id'],
			':so_credit_days' => $_REQUEST['so_credit_days'],
			':so_credit_due_date' => $_REQUEST['so_credit_due_date'],
			':so_credit_approval_remarks' => $_REQUEST['so_credit_approval_remarks'],
			':so_approve_status' => '3',
			':so_approve_by' => $_SESSION['_user_id'],
			':pay_status' =>'4',
			':so_approve_date_time' => date('Y-m-d H:i:s')
		);
		$stmt->execute($data);
		if ($stmt->rowCount() == 0) {
			throw new Exception("This sales order is not waiting for credit approval..!");
		}
		db_commit($conn);
		header("location:lst_sales_receipt.php");	
		die();
		// print_r($data);die();
	} catch (Exception $e) {
		fnLogError($e);
		db_rollback($conn);
		$_SESSION['_msg_err'] = filter_var($e->getMessage(), FILTER_SANITIZE_STRING);
	}
	header("location:lst_sales_receipt.php");
	die();
}
?>

<!-- Basic modal -->
<div id="modalSoDets" class="modal fade" tabindex="-1">
	<div class="modal-dialog   modal-dialog-scrollable">
		<div class="modal-content">
			<div class="modal-header pb-2 pt-2 bg-modal">
				<h6 class="modal-title" style="width: 700px;">
				</span><span id="m_sales_code1" class="font-weight-bold"></span>
				</h6>
				<!-- <h6 class="modal-title font-weight-bold"><span id="m_sales_rec"></span> - <span id="inv_netamt" class="font-weight-bold"></span></h6> -->
				<button type="button" class="close" data-dismiss="modal">&times;</button>
			</div>
			<form action="modal_so_det.php" method="POST">
				<?php csrf_fields('modal_so_det'); ?>
			<div class="modal-body py-0" id="m_sales_id">
				<div class="col-md-6 pt-5 pb-5 text-center">
					<span id="spinner-light" class="text-loading">
						<i class="icon-spinner spinner mr-2 "></i>
						Loading ...
					</span>
				</div>
			</div>


			<!-- <div class="modal-body py-0" id="m_sales_name">
				<div class="col-md-6 pt-5 pb-5 text-center">
					<span id="spinner-light" class="text-loading">
						<i class="icon-spinner spinner mr-2 "></i>
						Loading ...
					</span>
				</div>
			</div> -->

					<div class="container">
					<div style="text-align: center"><hr>
	
						<INPUT class="btn btn-success" type="submit" name="CONFIRM" value="Approve Credit Sales">
						<INPUT class="btn btn-light mr-2" type="button" name="cancel" value="Close" onClick="javascript:window.location.href='lst_so_approval.php'">
					
					</div>
				</div><br>
			</form>

			<div class="modal-footer pt-0 pb-2 bg-modal">
				
			</div>
			
		</div>
	</div>
</div>
<!-- /basic modal -->

<!-- Basic modal -->

    <div id="modalitemgrpDets" class="modal fade" tabindex="-1">
		<div class="modal-dialog modal-lg modal-dialog-scrollable   modal-dialog-centered" role="dialog">
			<div class="modal-content">
				<div class="modal-header pb-2 pt-2 bg-modal">
					<h6 class="modal-title"></span><span id="m_item_group_id" class="font-weight-bold"></span></h6>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
	    		<div class="modal-body py-0" id="m_item_group_code">				
		    		<div class="col-md-12 pt-5 pb-5 text-center">
			    		<span id="spinner-light" class="text-loading">
				    		<i class="icon-spinner spinner mr-2 "></i>
							Loading ...
					    </span>
				    </div>
			    </div>
			    <div class="modal-footer pt-0 pb-2 bg-modal">				
				    <!--button type="button" class="btn btn-light" data-dismiss="modal">Close</button-->				
			    </div>
		    </div>
	    </div>
	</div>			
<!-- /basic modal -->